#include "othello_game.h"

Result OthelloGame::process(const cq::Target& current_target, const std::string& message)
{
    return Result();
}
